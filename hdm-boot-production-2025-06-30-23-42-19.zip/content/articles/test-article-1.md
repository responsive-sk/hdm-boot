---
title: Test Article 1
slug: test-article-1
author: Test Author
excerpt: Excerpt for article 1
published: true
published_at: "2025-06-22 11:37:28"
category: test
tags: [test, phpunit]
reading_time: 5
---

Content for test article 1