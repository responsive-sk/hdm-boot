---
title: Hybrid Storage Test
slug: hybrid-test
author: System
published: true
category: testing
reading_time: 1
published_at: "2025-06-17 14:17:22"
---

# Hybrid Storage

This article is stored in a **Markdown file**! 📝