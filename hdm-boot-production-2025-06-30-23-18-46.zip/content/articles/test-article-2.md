---
title: Test Article 2
slug: test-article-2
author: Test Author
excerpt: Excerpt for article 2
published: true
published_at: "2025-06-22 11:37:28"
category: test
tags: [test, phpunit]
reading_time: 5
---

Content for test article 2