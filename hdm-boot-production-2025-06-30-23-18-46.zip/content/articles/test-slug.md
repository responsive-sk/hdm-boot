---
title: Test Article
slug: test-slug
author: Test Author
excerpt: Test excerpt
published: true
published_at: "2025-06-22 11:37:28"
category: test
tags: [test, phpunit]
reading_time: 5
---

This is test content for the article.